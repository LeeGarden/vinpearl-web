<div class="box-wp">
	<div class="trademark">
		<h2>CÁC ĐƠN VỊ TƯ VẤN THIẾT KẾ VÀ THI CÔNG</h2>
		<p>We accomplish individual projects</p>
		<div class="trademark-slide">
			<img src="{{ asset('client') }}/img/trademark.jpg" alt="">
		</div>
	</div>
</div>
