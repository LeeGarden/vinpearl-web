<meta charset="UTF-8">
<title>VINPEARL</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" type="text/css" href="{{ asset('client') }}/css/animate.css">
<link rel="stylesheet" type="text/css" href="{{ asset('client') }}/css/hover.css">
<link rel="stylesheet" type="text/css" href="{{ asset('client') }}/css/font-awesome.css">
<link rel="stylesheet" type="text/css" href="{{ asset('client') }}/css/slick.css">
<link rel="stylesheet" type="text/css" href="{{ asset('client') }}/js/datetimepicker/jquery.datetimepicker.css">
<link rel="stylesheet" type="text/css" href="{{ asset('client') }}/js/fancybox/jquery.fancybox.css">
<link rel="stylesheet" type="text/css" href="{{ asset('client') }}/js/fancybox/helpers/jquery.fancybox-buttons.css">
<link rel="stylesheet" type="text/css" href="{{ asset('client') }}/js/fancybox/helpers/jquery.fancybox-thumbs.css">
<link rel="stylesheet" type="text/css" href="{{ asset('client') }}/css/style.css">
<link rel="shortcut icon" href="{{ asset('') }}/favicon.ico">