<script type="text/javascript" src="{{ asset('client') }}/js/jquery-1.9.1.min.js"></script>
<script type="text/javascript" src="{{ asset('client') }}/js/slick.js"></script>
<script type="text/javascript" src="{{ asset('client') }}/js/fancybox/jquery.fancybox.js"></script>
<script type="text/javascript" src="{{ asset('client') }}/js/fancybox/helpers/jquery.fancybox-buttons.js"></script>
<script type="text/javascript" src="{{ asset('client') }}/js/fancybox/helpers/jquery.fancybox-thumbs.js"></script>
<script type="text/javascript" src="{{ asset('client') }}/js/datetimepicker/jquery.datetimepicker.full.js"></script>
<script type="text/javascript" src="{{ asset('client') }}/js/wow.min.js"></script>
<script type="text/javascript" src="{{ asset('client') }}/js/main.js"></script>